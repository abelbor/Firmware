#include "main.h"
#include "sAPI.h"

#define GREEN_THRESHOLD		0
#define YELLOW_THRESHOLD	255
#define RED_THRESHOLD		511
#define HEAVENS_GATE		1023

// FUNCION PRINCIPAL, PUNTO DE ENTRADA AL PROGRAMA LUEGO DE RESET.
int main(void) {

	// ------------- INICIALIZACIONES -------------

	// Inicializar la placa
	boardConfig();

	// Inicializar el conteo de Ticks con resolución de 1ms, sin tickHook
	tickConfig(1, 0);

	// Inicializar DigitalIO
	digitalConfig(0, ENABLE_DIGITAL_IO);

	// Configuración de pines de entrada para Teclas de la EDU-CIAA-NXP
	digitalConfig(TEC1, INPUT);
	digitalConfig(TEC2, INPUT);
	digitalConfig(TEC3, INPUT);
	digitalConfig(TEC4, INPUT);

	// Configuración de pines de salida para Leds de la EDU-CIAA-NXP
	digitalConfig(LEDR, OUTPUT);
	digitalConfig(LEDG, OUTPUT);
	digitalConfig(LEDB, OUTPUT);
	digitalConfig(LED1, OUTPUT);
	digitalConfig(LED2, OUTPUT);
	digitalConfig(LED3, OUTPUT);

	/* Inicializar AnalogIO
	 Posibles configuraciones:
	 *    ENABLE_ANALOG_INPUTS,  DISABLE_ANALOG_INPUTS,
	 *    ENABLE_ANALOG_OUTPUTS, DISABLE_ANALOG_OUTPUTS
	 */

	analogConfig(ENABLE_ANALOG_INPUTS);  // ADC
	analogConfig(ENABLE_ANALOG_OUTPUTS); // DAC

	// Variable para almacenar el valor leido del ADC CH1
	uint16_t muestra = 0;

	// Variable de delays no bloqueantes
	delay_t delay1;

	// Retardo no bloqueante con tiempo en ms
	delayConfig(&delay1, 400);

	while (1) {

		// retorna TRUE cuando se cumple el tiempo de retardo
		if (delayRead(&delay1)) {

			// Se lee la entrada analogica AI0 - ADC0 CH1
			muestra = analogRead(AI0);

			// Se escriben los valores en los leds
			digitalWrite(LED3, (muestra > GREEN_THRESHOLD));

			digitalWrite(LED2, (muestra > YELLOW_THRESHOLD));

			digitalWrite(LED1, (muestra > RED_THRESHOLD));

			digitalWrite(LEDR, (muestra == HEAVENS_GATE));
			digitalWrite(LEDG, (muestra == HEAVENS_GATE));
			digitalWrite(LEDB, (muestra == HEAVENS_GATE));

			// Se escribe la muestra en la salida analogicaAO - DAC
			analogWrite(AO, muestra);
		}

	}

	return 0;
}
